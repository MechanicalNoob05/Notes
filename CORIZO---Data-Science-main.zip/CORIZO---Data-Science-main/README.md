# CORIZO---Data-Science
This repo contains a few Private files for data science.
